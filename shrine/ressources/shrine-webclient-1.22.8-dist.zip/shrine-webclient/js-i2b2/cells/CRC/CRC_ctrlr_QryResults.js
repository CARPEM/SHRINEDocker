/**
 * @projectDescription	The Asynchronous Query Formatted Results controller .
 * @inherits 	i2b2.CRC.ctrlr
 * @namespace	i2b2.CRC.ctrlr.QueryFormattedResults
 * @author		Bhaswati Ghosh
 * @version 	1.3
 * ----------------------------------------------------------------------------------------
 */
 
i2b2.CRC.ctrlr.QueryResults = function(string) { 
		this.resultString = string; 
};

i2b2.CRC.ctrlr.currentQueryResults = false; 

