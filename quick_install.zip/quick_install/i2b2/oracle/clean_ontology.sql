drop user  I2B2_DB_SHRINE_ONT_USER cascade;

-- These tables are dropped by casaded :
--  drop table SHRINE;
--  drop table TABLE_ACCESS;
--  drop table SCHEMES;

