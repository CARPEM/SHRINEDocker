#!/bin/sh

apt-get install -y wget

apt-get install -y zip 

apt-get install -y unzip

apt-get autoclean
