#!/bin/sh

apt-get install -y wget

apt-get install -y zip 

apt-get install -y unzip

apt-get autoclean

echo "[install-mysql-server.sh] NOTE: Shrine saves only query history, not patient data"
echo "[install-mysql-server.sh] installing mysql which is the default database for SHRINE. Any SQL database can be used."

apt-get install -y mysql-server
apt-get autoclean
service mysql start
