-- Create the SHRINE database
/*drop database if exists SHRINE_DB_NAME;
create database SHRINE_DB_NAME; 

-- Create a SQL user for query history
grant all privileges on SHRINE_DB_NAME.* to SHRINE_MYSQL_USER@SHRINE_MYSQL_HOST identified by 'SHRINE_MYSQL_PASSWORD';

-- Create the steward database
drop database if exists SHRINE_STEWARD_DB_NAME;
create database SHRINE_STEWARD_DB_NAME; 

-- Create a SQL user for query history
grant all privileges on SHRINE_STEWARD_DB_NAME.* to SHRINE_STEWARD_MYSQL_USER@SHRINE_STEWARD_MYSQL_HOST identified by 'SHRINE_STEWARD_MYSQL_PASSWORD';

*/

-- modified to fit Postgres 2014-07-23
-- create user shrine_ont IDENTIFIED BY 'demouser';

-- create matching schema
/*
create schema shrine_ont;

-- i2b2metadata.table_access
-- grant all privileges on all tables in schema shrine_ont to shrine_ont;
-- grant all privileges on all sequences in schema shrine_ont to shrine_ont;
-- grant all privileges on all functions in schema shrine_ont to shrine_ont;

grant all privileges on shrine_ont.shrine_ont to shrine_ont;

-- Create the SHRINE database
drop database if exists SHRINE_DB_NAME;
create database SHRINE_DB_NAME;

-- Create a SQL user for query history
create user SHRINE_MYSQL_USER@SHRINE_MYSQL_HOST IDENTIFIED BY 'SHRINE_MYSQL_PASSWORD';
grant all privileges on SHRINE_DB_NAME.* to SHRINE_MYSQL_USER@'SHRINE_MYSQL_HOST' identified by 'SHRINE_MYSQL_PASSWORD';

-- Create the steward database
drop database if exists SHRINE_STEWARD_DB_NAME;
create database SHRINE_STEWARD_DB_NAME;

-- Create a SQL user for query history
create user SHRINE_STEWARD_MYSQL_USER@SHRINE_STEWARD_MYSQL_HOST IDENTIFIED BY 'SHRINE_STEWARD_MYSQL_PASSWORD';
grant all privileges on SHRINE_STEWARD_DB_NAME.* to SHRINE_STEWARD_MYSQL_USER@'SHRINE_STEWARD_MYSQL_HOST' identified by 'SHRINE_STEWARD_MYSQL_PASSWORD';
*/
