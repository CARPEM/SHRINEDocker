# Development Example #4: Communicator Plugin
This plugin was created as an example of how to create a plugin for the i2b2 Web Client. This particular plugin demonstrates how to develop a tool for interacting with standard Communicator objects within the i2b2 Web Client (controller code).

## Plugin Development: 
### Author/s: 
* Nick Benik
* Griffin Weber, MD, Ph.D

### Institution/s:
* Beth Israel Deaconess Hospital, Boston, MA