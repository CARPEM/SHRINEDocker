# exportXLS Plugin
A plugin developed for the i2b2 Web Client. This plugin tabulates patient data and applicable specified concepts. The tabulated data can then be exported into a spreadsheet format.

## Plugin Development: 
### Author/s: 
 * Mauro Bucalo, Universit&agrave; di Pavia
 * S. Wayne Chan, University of Massachusetts Medical School
 * Axel Newe, FAU Erlangen-Nuremberg
 * PARIS Nicolas, H&ocirc;pital Ambroise-Par&eacute;


### Institution/s:
* Universit&agrave; di Pavia
* University of Massachusetts Medical School
* FAU Erlangen-Nuremberg
* H&ocirc;pital Ambroise-Par&eacute;