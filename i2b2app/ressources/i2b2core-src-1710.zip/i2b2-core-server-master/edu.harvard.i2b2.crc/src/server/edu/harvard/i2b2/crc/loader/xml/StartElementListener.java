package edu.harvard.i2b2.crc.loader.xml;

public interface StartElementListener {
	public void process(Object object);
}
