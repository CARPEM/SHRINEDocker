package edu.harvard.i2b2.crc.loader.ejb;

public interface LoaderStatusBeanRemote extends ILoaderStatusBean{


}