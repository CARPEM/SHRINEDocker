package edu.harvard.i2b2.crc.ejb.analysis;

public class HiveDAOFactory {

}
