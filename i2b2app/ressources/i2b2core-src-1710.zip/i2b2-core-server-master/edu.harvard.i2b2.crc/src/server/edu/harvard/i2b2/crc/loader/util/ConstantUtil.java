package edu.harvard.i2b2.crc.loader.util;

public class ConstantUtil {
	public static final String HIVE_SOURCE_NAME = "HIVE"; 
}
