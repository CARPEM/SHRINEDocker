package edu.harvard.i2b2.crc.loader.ejb;

public interface DataMartLoaderAsyncBeanLocal extends IDataMartLoaderBean {
	
}