package edu.harvard.i2b2.crc.dao.setfinder;

public class QueryStatusTypeId {
	public final static int STATUSTYPE_ID_QUEUED = 1;
	public final static int STATUSTYPE_ID_PROCESSING = 2;
	public final static int  STATUSTYPE_ID_FINISHED = 3;
	public final static int STATUSTYPE_ID_ERROR = 4;
	public final static int STATUSTYPE_ID_INCOMPLETE = 5;
	public final static int STATUSTYPE_ID_COMPLETED = 6;
}
