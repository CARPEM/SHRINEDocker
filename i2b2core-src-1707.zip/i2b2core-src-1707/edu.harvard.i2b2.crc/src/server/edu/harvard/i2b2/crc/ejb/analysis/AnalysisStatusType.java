package edu.harvard.i2b2.crc.ejb.analysis;

public class AnalysisStatusType {
	public final static String ERROR_STATUS = "ERROR";
	public final static String TIMEOUT_STATUS = "TIMEOUT";
	public final static String COMPLETED_STATUS = "COMPLETED";
	public final static String QUEUED_STATUS = "QUEUED";
}
