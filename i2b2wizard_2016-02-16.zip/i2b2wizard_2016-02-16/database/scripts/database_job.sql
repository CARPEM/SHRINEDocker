alter system set processes=500 scope=spfile;
commit;
